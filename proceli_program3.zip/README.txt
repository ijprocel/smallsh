To compile the code, simply use the command "make" or "make smallsh" to run the compile script in the makefile.

To run the program, use the command "./smallsh"